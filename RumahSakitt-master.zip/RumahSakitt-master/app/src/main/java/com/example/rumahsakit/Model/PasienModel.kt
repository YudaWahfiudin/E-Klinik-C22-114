package com.example.rumahsakit.Model

data class PasienModel (
    val id: Int?,
    val pasien:String?,
    val status:String?,
    val kamar :String?
        )
