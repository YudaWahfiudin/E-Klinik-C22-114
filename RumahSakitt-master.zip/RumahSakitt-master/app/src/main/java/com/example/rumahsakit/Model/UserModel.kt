package com.example.rumahsakit.Model

data class UserModel (
    val id: Int?,
    val username:String?,
    val password:String?,
    val status:Int?
)