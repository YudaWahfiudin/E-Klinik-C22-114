package com.example.rumahsakit.Model

data class ObatModel (
    val id: Int?,
    val obat:String?,
    val deskripsi:String?
)
