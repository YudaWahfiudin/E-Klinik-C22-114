package com.example.rumahsakit.Model

data class DokterModel (
    val id: Int?,
    val nama:String?,
    val jam:String?,
    val jenis:String?
        )
