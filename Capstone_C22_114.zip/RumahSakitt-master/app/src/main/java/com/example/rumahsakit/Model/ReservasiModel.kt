package com.example.rumahsakit.Model

data class ReservasiModel (
    val id:Int?,
    val nama:String?,
    val jam:String?,
    val id_dokter:Int?
        )
